.onLoad <- function(...) {
  message("HAVE YOU CONSIDERED USING BASE?")
}
